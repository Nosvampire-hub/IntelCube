using UnityEngine.UI;
using UnityEngine;
using GooglePlayGames.BasicApi;
using UnityEngine.SocialPlatforms;
using GooglePlayGames;
using TMPro;

public class GooglePlayServices : MonoBehaviour
{
    public bool loginSuccess = false;
    public string userName = "";
    public void Start()
    {
        PlayGamesPlatform.Instance.Authenticate(ProcessAuthentication);
    }

    internal void ProcessAuthentication(SignInStatus status)
    {
        if (status == SignInStatus.Success)
        {

            PlayGamesPlatform.Activate();

            GameObject Username = GameObject.Find("NameTag");
            TextMeshPro userText = Username.GetComponent<TextMeshPro>();
            userName = Social.localUser.userName;
            userText.SetText(userName);
            loginSuccess = true;

            // Continue with Play Games Services
            Social.ReportProgress("CgkIiMPpv9UUEAIQAg", 100.0f, (bool success) =>
           {
           });


        }
        else
        {

            GameObject Username = GameObject.Find("NameTag");
            TextMeshPro userText = Username.GetComponent<TextMeshPro>();
            userText.SetText("Authentication Failed" + status.ToString());
            // Disable your integration with Play Games Services or show a login button
            // to ask users to sign-in. Clicking it should call
            // PlayGamesPlatform.Instance.ManuallyAuthenticate(ProcessAuthentication).
        }
    }





    public void ShowLeaderboard()
    {
		PlayGamesPlatform.Instance.Authenticate(ProcessAuthentication);

        if (loginSuccess)
        {
            Social.ShowLeaderboardUI();
        }
    }

    public void ShowAchievements()
    {
		PlayGamesPlatform.Instance.Authenticate(ProcessAuthentication);
        if (loginSuccess)
        {
            Social.ShowAchievementsUI();
        }
    }

    public void PostScore(int score)
    {
		PlayGamesPlatform.Instance.Authenticate(ProcessAuthentication);

        if (loginSuccess)
        {
            Social.ReportScore(score, "CgkIiMPpv9UUEAIQAw", (bool success) =>
            {
            });
        }
    }
}